<a class="main-footer__button button button--plus" href="?addTask<?= isset($_GET['project']) ? "&project=".$_GET['project'] : ""?>">Добавить задачу</a>
