
<main class="content__main">
    <h2 class="content__main-heading">Список задач</h2>

    <form class="search-form" action="index.php" method="GET" autocomplete="off">
        <input class="search-form__input" type="text" name="SearchByTasks" value="<?=getGetVal('SearchByTasks')?>" placeholder="Поиск по задачам">

        <input class="search-form__submit" type="submit" name="" value="Искать">
    </form>

    <div class="tasks-controls">
        <nav class="tasks-switch">
            <a href="<?=$urlnavigationOfParam?>AllTask" class="tasks-switch__item <?= 'AllTask'===$currentparam ? 'tasks-switch__item--active' : ''?>">Все задачи</a>
            <a href="<?=$urlnavigationOfParam?>Agenda" class="tasks-switch__item <?= 'Agenda'===$currentparam ? 'tasks-switch__item--active' : ''?>">Повестка дня</a>
            <a href="<?=$urlnavigationOfParam?>Tomorrow" class="tasks-switch__item <?= 'Tomorrow'===$currentparam ? 'tasks-switch__item--active' : ''?>">Завтра</a>
            <a href="<?=$urlnavigationOfParam?>Overdue" class="tasks-switch__item <?= 'Overdue'===$currentparam ? 'tasks-switch__item--active' : ''?>">Просроченные</a>
        </nav>

        <label class="checkbox">
            <!--добавить сюда атрибут "checked", если переменная $show_complete_tasks равна единице-->
            <input class="checkbox__input visually-hidden show_completed" type="checkbox" <?php if($show_complete_tasks === 1): ?>checked <?php endif; ?> >

            <span class="checkbox__text">Показывать выполненные</span>
        </label>
    </div>

    <table class="tasks">
        <?php
            if(count($errors) != 0){
                foreach ($errors as $key => $value) {
                    echo "<h3><span style='color: #150b0b'>" .$key.": </span>".$value."</h3>";
                }
            }
        ?>

    	<?php foreach ($tasks as $key => $task): ?>
    		<?php if( !$task['Completed'] || ($show_complete_tasks === 1 && $task['Completed']) ): ?>
                <?php
                $time_difference =  isset($tasks[$key]['DateOfCompletion']) ? strtotime($tasks[$key]['DateOfCompletion']) - time() : null ;
                if( empty($_GET['ParamSelect']) || ($_GET['ParamSelect'] === "AllTask")  ||
                    (
                        isset($tasks[$key]['DateOfCompletion']) &&
                        (
                            ($_GET['ParamSelect'] === "Overdue" &&  $time_difference <= -86400 ) ||
                            ($_GET['ParamSelect'] === "Tomorrow" && $time_difference  >= 0 && $time_difference  <= 86400) ||
                            ($_GET['ParamSelect'] === "Agenda" && $time_difference  >= -86400 && $time_difference  <= 0)
                        )
                    )
                    ): ?>

                <tr class="tasks__item task <?php if($task['Completed'])echo('task--completed') ?> <?php if( isset($tasks[$key]['DateOfCompletion']) && $time_difference <= -86400)echo('task--important') ?>">
                    <td class="task__select">
                        <label class="checkbox task__checkbox">
                            <form action="" id="form<?=$tasks[$key]['ID']?>" method="post">
                                <a onclick="document.getElementById('form<?=$tasks[$key]['ID']?>').submit(); return false;" style='color: #000 !important;text-decoration: none' href="">
                                    <input class="checkbox__input visually-hidden task__checkbox" type="checkbox" <?php if($task['Completed'])echo('checked') ?>>
                                    <span class="checkbox__text"><?=htmlspecialchars($task['Name']) ?></span> </a>

                                <input type="hidden" name="task_id" value="<?=$tasks[$key]['ID']?>">
                                <input type="hidden" name="chk" value="<?=$tasks[$key]['Completed']?>">
                            </form>
                        </label>
                    </td>
                    <td class="task__file"> <?= isset($task['File']) ? '<a class="download-link" href="'.$task['File'].'">'.getNameFileOfURl($task['File']).'</a> ' : ""?></td>
                    <?='<td class="task__date">'.$task['DateOfCompletion'].'</td>'?>
                </tr>
                 <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; ?>
    </table>
</main>
